from django.apps import AppConfig


class CurrentConfig(AppConfig):
    name = 'current'
